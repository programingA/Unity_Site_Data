package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/user/change-password")
public class ChangePasswordServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        // 1) 로그인 체크
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // ✅ LoginServlet과 똑같은 키 이름 사용: "loginId"
        String username = (String) session.getAttribute("loginId");
        if (username == null || username.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // 2) 새 비밀번호 파라미터 읽기
        // MyPassword.jsx에서 application/x-www-form-urlencoded 로
        // newPassword=... 형태로 보내고 있음
        String newPassword = req.getParameter("newPassword");

        if (newPassword == null || newPassword.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("FAIL|새 비밀번호를 입력해주세요.");
            return;
        }

        // (길이 검증은 프론트에서 이미 하고 있지만, 서버에서도 한 번 더 체크 가능)
        if (newPassword.length() < 4) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("FAIL|비밀번호는 최소 4자 이상이어야 합니다.");
            return;
        }

        // 3) DAO 호출해서 비밀번호 변경
        UserDAO dao = new UserDAO();
        boolean success = dao.changePassword(username, newPassword);

        if (success) {
            // 비밀번호 변경 후에는 재로그인 요구 → 세션 무효화
            session.invalidate();
            out.print("SUCCESS|비밀번호가 변경되었습니다.");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("FAIL|비밀번호 변경에 실패했습니다.");
        }
    }
}
