package com.memoryspace.api;

import com.memoryspace.user.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/api/user/update")
public class UpdateUserServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        // 1) 세션 / 로그인 체크
        HttpSession session = req.getSession(false);
        if (session == null) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // ✅ LoginServlet에서 저장한 키 이름과 동일하게 사용: "loginId"
        String username = (String) session.getAttribute("loginId");
        if (username == null || username.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            out.print("FAIL|로그인이 필요합니다.");
            return;
        }

        // 2) 파라미터 읽기 (x-www-form-urlencoded)
        String nickname = req.getParameter("nickname");
        String email = req.getParameter("email");
        String liveIn = req.getParameter("liveIn");

        if (nickname == null || nickname.trim().isEmpty()
                || email == null || email.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("FAIL|닉네임과 이메일은 필수입니다.");
            return;
        }

        // liveIn은 null일 수 있으니 NPE 방지
        if (liveIn == null) {
            liveIn = "";
        }

        // 3) DB 업데이트
        UserDAO dao = new UserDAO();
        boolean success = dao.updateUser(username, nickname, email, liveIn);

        if (success) {
            // 세션에 저장된 닉네임도 함께 갱신
            session.setAttribute("nickname", nickname);
            out.print("SUCCESS|회원정보가 수정되었습니다.");
        } else {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("FAIL|회원정보 수정에 실패했습니다.");
        }
    }
}
