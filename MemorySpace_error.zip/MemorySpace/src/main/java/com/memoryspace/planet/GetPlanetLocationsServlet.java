package com.memoryspace.planet;

import com.google.gson.Gson;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 지명 정보가 있는 모든 행성 미디어 데이터를 반환하는 API
 * GET /api/planet-locations
 */
@WebServlet("/api/map")
public class GetPlanetLocationsServlet extends HttpServlet {

    private final PlanetMediaDAO planetMediaDAO = new PlanetMediaDAO();
    private final NominatimService nominatimService = new NominatimService();
    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // 응답 설정
        response.setContentType("application/json; charset=UTF-8");
        response.setHeader("Access-Control-Allow-Origin", "*"); 
        response.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");

        try {
            // 1. DB에서 모든 위치 데이터 조회 
            List<PlanetMediaDTO> locations = planetMediaDAO.getAllLocations();
            int geocodedCount = 0;

            // 2. 좌표가 없는 데이터만 Nominatim API를 호출하여 채우기
            for (PlanetMediaDTO location : locations) {
                // 좌표가 Null인 경우에만 지오코딩 수행
                if (location.getLatitude() == null || location.getLongitude() == null) {
                    String locationName = location.getLocationName();
                    
                    if (locationName != null && !locationName.trim().isEmpty()) {
                        System.out.println("⏳ Geocoding needed for: " + locationName);
                        
                        // Nominatim 호출 (IOException, ClassNotFound 등 예외 발생 가능)
                        Double[] coords = nominatimService.geocode(locationName);
                        
                        if (coords != null) {
                            Double lat = coords[0];
                            Double lng = coords[1];
                            
                            // DTO 업데이트
                            location.setLatitude(lat);
                            location.setLongitude(lng);
                            
                            // DB 업데이트 (캐싱)
                            planetMediaDAO.updateCoordinates(location.getId(), lat, lng);
                            geocodedCount++;
                        }
                    }
                }
            }

            // 3. 클라이언트로 보낼 데이터 정제
            List<MapLocationData> mapDataList = locations.stream()
                .filter(loc -> loc.getLatitude() != null && loc.getLongitude() != null)
                .map(loc -> new MapLocationData(
                    loc.getId(), 
                    loc.getLocationName(), 
                    loc.getLatitude(), 
                    loc.getLongitude(), 
                    loc.getSizeBytes() != null ? loc.getSizeBytes().intValue() : 1 
                ))
                .collect(Collectors.toList());


            // 4. JSON 변환 및 응답
            String json = gson.toJson(mapDataList);
            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write(json);
            
            System.out.println("✅ Successfully returned " + mapDataList.size() + " locations (Geocoded " + geocodedCount + " new locations)");
            
        } catch (Exception e) {
            // 🚨 최종 예외 포착 및 콘솔 출력 강화 🚨
            e.printStackTrace(); 
            String errorMsg = e.getClass().getName() + ": " + e.getMessage();
            
            // 브라우저로 500 에러와 함께 구체적인 오류 종류를 반환합니다.
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"" + errorMsg.replace("\"", "'") + "\"}");
        }
    }
    
    // ... (doOptions 메서드 생략)
}

// React 클라이언트의 MapPage.jsx가 기대하는 형식에 맞추기 위한 내부 클래스 (간결화)
class MapLocationData {
    private Long id;
    private String name; // locationName
    private Double lat;
    private Double lng;
    private Integer value; // sizeBytes를 value로 사용

    public MapLocationData(Long id, String name, Double lat, Double lng, Integer value) {
        this.id = id;
        this.name = name;
        this.lat = lat;
        this.lng = lng;
        this.value = value;
    }
}