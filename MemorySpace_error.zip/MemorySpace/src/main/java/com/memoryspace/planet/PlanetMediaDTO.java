package com.memoryspace.planet;

public class PlanetMediaDTO {
    private Long id;
    private Long planetId;
    private String mediaType;
    private String filePath;
    // private String mimeType; // ⚠️ 제거됨
    private Long sizeBytes;
    private String locationName;
    private Double latitude;
    private Double longitude;

    // 기본 생성자
    public PlanetMediaDTO() {}

    // 전체 생성자 (mimeType 제거)
    public PlanetMediaDTO(Long id, Long planetId, String mediaType, String filePath, 
                          String locationName, Double latitude, Double longitude) {
        this.id = id;
        this.planetId = planetId;
        this.mediaType = mediaType;
        this.filePath = filePath;
        this.locationName = locationName;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getPlanetId() {
        return planetId;
    }

    public void setPlanetId(Long planetId) {
        this.planetId = planetId;
    }

    public String getMediaType() {
        return mediaType;
    }

    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    // ⚠️ getMimeType() 및 setMimeType() 제거됨
    /*
    public String getMimeType() {
        return mimeType;
    }
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
    */

    public Long getSizeBytes() {
        return sizeBytes;
    }

    public void setSizeBytes(Long sizeBytes) {
        this.sizeBytes = sizeBytes;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "PlanetMediaDTO{" +
                "id=" + id +
                ", planetId=" + planetId +
                ", mediaType='" + mediaType + '\'' +
                ", locationName='" + locationName + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}