// src/main/java/com/memoryspace/admin/TestServlet.java
package com.memoryspace.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name = "TestServlet", urlPatterns = {"/api/test"})
public class TestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        System.out.println("=== TestServlet GET called ===");
        
        resp.setContentType("application/json; charset=UTF-8");
        resp.getWriter().write("{\"message\":\"Test servlet works!\"}");
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        System.out.println("=== TestServlet POST called ===");
        
        resp.setContentType("application/json; charset=UTF-8");
        resp.getWriter().write("{\"message\":\"Test POST works!\"}");
    }
}