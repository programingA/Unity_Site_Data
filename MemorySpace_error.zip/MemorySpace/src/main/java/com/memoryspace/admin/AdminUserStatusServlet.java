// src/main/java/com/memoryspace/admin/AdminUserStatusServlet.java
package com.memoryspace.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet(
        name = "AdminUserStatusServlet",
        urlPatterns = {
                "/api/admin/user-status",   // 우리가 실제로 쓰는 URL
                "/api/admin/test-status"    // 추가 테스트용 URL
        }
)
public class AdminUserStatusServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        System.out.println("========== [DEBUG] AdminUserStatusServlet.doGet ==========");
        System.out.println("  URI   = " + req.getRequestURI());
        System.out.println("  method= " + req.getMethod());

        resp.setContentType("text/plain; charset=UTF-8");
        resp.getWriter().write("GET OK: " + req.getRequestURI());
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        System.out.println("========== [DEBUG] AdminUserStatusServlet.doPost ==========");
        System.out.println("  URI   = " + req.getRequestURI());
        System.out.println("  method= " + req.getMethod());

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/plain; charset=UTF-8");

        // 들어온 파라미터 찍어보기
        req.getParameterMap().forEach((k, v) -> {
            String joined = String.join(",", v);
            System.out.println("  Param [" + k + "] = " + joined);
        });

        resp.getWriter().write("POST OK: " + req.getRequestURI());
    }
}
