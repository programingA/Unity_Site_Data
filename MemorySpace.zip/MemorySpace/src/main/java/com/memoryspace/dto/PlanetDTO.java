package com.memoryspace.dto;

public class PlanetDTO {
    private long id;
    private long starId;
    private String name;
    private boolean isDeleted;

    public PlanetDTO(long id, long starId, String name, boolean isDeleted) {
        this.id = id;
        this.starId = starId;
        this.name = name;
        this.isDeleted = isDeleted;
    }

    public void setId(long id) {
		this.id = id;
	}

	public void setStarId(long starId) {
		this.starId = starId;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public long getId() { return id; }
    public long getStarId() { return starId; }
    public String getName() { return name; }
    public boolean isDeleted() { return isDeleted; }
}
