// src/main/java/com/memoryspace/admin/AdminStatsServlet.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet(name = "AdminStatsServlet", urlPatterns = {"/api/admin/stats"})
public class AdminStatsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json; charset=UTF-8");

        try (Connection conn = DBConnectionUtil.getConnection()) {

            // 1) 전체 회원 수
            long totalUsers = 0;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COUNT(*) FROM users"
            );
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalUsers = rs.getLong(1);
            }

            // 2) 사용된 총 저장용량 (planet_media)
            long usedBytes = 0;
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT COALESCE(SUM(sizeBytes),0) FROM planet_media"
            );
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) usedBytes = rs.getLong(1);
            }

            // 전체 용량 (10GB 고정)
            long totalBytes = 10L * 1024 * 1024 * 1024;

            // 3) 지역 분포 (사용자 거주 지역 기준)
            Map<String, Long> regionMap = new LinkedHashMap<>();
            try (PreparedStatement ps = conn.prepareStatement(
                    "SELECT liveIn, COUNT(*) FROM users GROUP BY liveIn"
            );
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String region = rs.getString(1);
                    long count = rs.getLong(2);
                    if (region == null) region = "기타";
                    regionMap.put(region, count);
                }
            }

            // JSON 만들기
            StringBuilder json = new StringBuilder();
            json.append("{");

            json.append("\"totalUsers\":").append(totalUsers).append(",");

            json.append("\"storage\":{");
            json.append("\"used\":").append(usedBytes).append(",");
            json.append("\"total\":").append(totalBytes);
            json.append("},");

            json.append("\"regions\":{");
            boolean first = true;
            for (Map.Entry<String, Long> entry : regionMap.entrySet()) {
                if (!first) json.append(",");
                json.append("\"").append(entry.getKey()).append("\":").append(entry.getValue());
                first = false;
            }
            json.append("}");

            json.append("}");

            resp.getWriter().write(json.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(500);
            resp.getWriter().write("{\"error\":\"DB error\"}");
        }
    }
}
