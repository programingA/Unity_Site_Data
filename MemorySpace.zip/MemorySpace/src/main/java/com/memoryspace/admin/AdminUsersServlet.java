// src/main/java/com/memoryspace/admin/AdminUsersServlet.java
package com.memoryspace.admin;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "AdminUsersServlet", urlPatterns = {"/api/admin/users"})
public class AdminUsersServlet extends AbstractAdminServlet {

    private final AdminDAO adminDAO = new AdminDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        if (!ensureAdmin(req, resp)) {
            return;
        }

        resp.setContentType("application/json; charset=UTF-8");

        try {
            List<AdminDAO.AdminUserSummary> list = adminDAO.findAllUsersWithStats();
            List<String> jsonRows = new ArrayList<>();

            for (AdminDAO.AdminUserSummary u : list) {
                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(u.id).append(",");
                sb.append("\"username\":\"").append(escapeJson(u.username)).append("\",");
                sb.append("\"nickname\":\"").append(escapeJson(u.nickname)).append("\",");
                sb.append("\"email\":\"").append(escapeJson(u.email)).append("\",");

                sb.append("\"liveIn\":\"")
                  .append(escapeJson(u.liveIn == null ? "" : u.liveIn))
                  .append("\",");

                sb.append("\"role\":\"").append(escapeJson(u.role)).append("\",");
                sb.append("\"status\":\"").append(escapeJson(u.status)).append("\",");

                String penaltyEndStr = (u.penaltyEndAt == null) ? "" : u.penaltyEndAt.toString();
                sb.append("\"penaltyEndAt\":\"").append(escapeJson(penaltyEndStr)).append("\",");

                sb.append("\"postCount\":").append(u.postCount).append(",");
                sb.append("\"reportCount\":").append(u.reportCount).append(",");

                String lastLoginStr = (u.lastLoginTime == null) ? "" : u.lastLoginTime.toString();
                sb.append("\"lastLoginTime\":\"").append(escapeJson(lastLoginStr)).append("\"");

                sb.append("}");
                jsonRows.add(sb.toString());
            }

            String json = "{ \"users\": [" + String.join(",", jsonRows) + "] }";
            resp.getWriter().write(json);

        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"DB error\"}");
        }
    }
}
