// src/main/java/com/memoryspace/admin/AdminUsersServlet.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "AdminUsersServlet", urlPatterns = {"/api/admin/users"})
public class AdminUsersServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json; charset=UTF-8");

        List<String> jsonRows = new ArrayList<>();

        String sql =
                "SELECT u.id, u.username, u.nickname, u.email, u.liveIn, u.role, " +
                "       COALESCE(COUNT(p.id), 0) AS postCount " +
                "FROM users u " +
                "LEFT JOIN stars s ON s.userId = u.id " +
                "LEFT JOIN planets p ON p.starId = s.id AND p.isDeleted = 0 " +
                "GROUP BY u.id, u.username, u.nickname, u.email, u.liveIn, u.role " +
                "ORDER BY u.id DESC";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("id");
                String username = rs.getString("username");
                String nickname = rs.getString("nickname");
                String email = rs.getString("email");
                String liveIn = rs.getString("liveIn");
                String role = rs.getString("role");
                long postCount = rs.getLong("postCount");

                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(id).append(",");
                sb.append("\"username\":\"").append(escapeJson(username)).append("\",");
                sb.append("\"nickname\":\"").append(escapeJson(nickname)).append("\",");
                sb.append("\"email\":\"").append(escapeJson(email)).append("\",");
                sb.append("\"liveIn\":\"")
                        .append(liveIn == null ? "" : escapeJson(liveIn))
                        .append("\",");
                sb.append("\"role\":\"").append(escapeJson(role)).append("\",");
                sb.append("\"postCount\":").append(postCount);
                sb.append("}");
                jsonRows.add(sb.toString());
            }

            String json = "{ \"users\": [" + String.join(",", jsonRows) + "] }";
            resp.getWriter().write(json);

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"DB error\"}");
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
