// src/main/java/com/memoryspace/admin/AdminUsersServlet.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;   // ✅ 커넥터는 이것만 사용

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "AdminUsersServlet", urlPatterns = {"/api/admin/users"})
public class AdminUsersServlet extends HttpServlet {

    // ✅ 여기에는 getConnection() 따로 안 만든다!
    //    DB 연결은 전부 DBConnectionUtil.getConnection()만 사용.

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json; charset=UTF-8");

        List<String> jsonRows = new ArrayList<>();

        /*
         * users 기준으로
         *  - 게시물 수(postCount): planets(삭제 안 된 것만)
         *  - 신고 수(reportCount): 해당 planets가 reports에 몇 번 신고되었는지
         *  - 마지막 로그인(lastLoginTime): login_log에서 user_id = username 기준
         *  - 상태(status), 패널티 종료 시간(penaltyEndAt)
         */
        String sql =
                "SELECT u.id, u.username, u.nickname, u.email, u.liveIn, u.role, " +
                "       u.status, u.penaltyEndAt, " +
                "       COALESCE(COUNT(DISTINCT p.id), 0) AS postCount, " +
                "       COALESCE(COUNT(DISTINCT r.id), 0) AS reportCount, " +
                "       MAX(l.login_time) AS lastLoginTime " +
                "FROM users u " +
                "LEFT JOIN stars s ON s.userId = u.id " +
                "LEFT JOIN planets p ON p.starId = s.id AND p.isDeleted = 0 " +
                "LEFT JOIN reports r ON r.planetId = p.id " +
                "LEFT JOIN login_log l ON l.user_id = u.username " +
                "GROUP BY u.id, u.username, u.nickname, u.email, u.liveIn, u.role, u.status, u.penaltyEndAt " +
                "ORDER BY u.id DESC";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("id");
                String username = rs.getString("username");
                String nickname = rs.getString("nickname");
                String email = rs.getString("email");
                String liveIn = rs.getString("liveIn");
                String role = rs.getString("role");
                String status = rs.getString("status");
                Timestamp penaltyEndAt = rs.getTimestamp("penaltyEndAt");
                long postCount = rs.getLong("postCount");
                long reportCount = rs.getLong("reportCount");
                Timestamp lastLoginTime = rs.getTimestamp("lastLoginTime");

                String penaltyEndStr = (penaltyEndAt == null)
                        ? ""
                        : penaltyEndAt.toString();  // "YYYY-MM-DD HH:MM:SS"
                String lastLoginStr = (lastLoginTime == null)
                        ? ""
                        : lastLoginTime.toString();

                // JSON 수동 생성
                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(id).append(",");
                sb.append("\"username\":\"").append(escapeJson(username)).append("\",");
                sb.append("\"nickname\":\"").append(escapeJson(nickname)).append("\",");
                sb.append("\"email\":\"").append(escapeJson(email)).append("\",");
                sb.append("\"liveIn\":\"")
                  .append(liveIn == null ? "" : escapeJson(liveIn))
                  .append("\",");
                sb.append("\"role\":\"").append(escapeJson(role)).append("\",");
                sb.append("\"status\":\"").append(escapeJson(status)).append("\",");
                sb.append("\"penaltyEndAt\":\"").append(escapeJson(penaltyEndStr)).append("\",");
                sb.append("\"postCount\":").append(postCount).append(",");
                sb.append("\"reportCount\":").append(reportCount).append(",");
                sb.append("\"lastLoginTime\":\"").append(escapeJson(lastLoginStr)).append("\"");
                sb.append("}");
                jsonRows.add(sb.toString());
            }

            String json = "{ \"users\": [" + String.join(",", jsonRows) + "] }";
            resp.getWriter().write(json);

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"DB error\"}");
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
