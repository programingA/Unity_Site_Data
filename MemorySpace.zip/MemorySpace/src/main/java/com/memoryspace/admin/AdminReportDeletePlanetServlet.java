// src/main/java/com/memoryspace/admin/AdminReportDeletePlanetServlet.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "AdminReportDeletePlanetServlet", urlPatterns = {"/api/admin/reports/delete-planet"})
public class AdminReportDeletePlanetServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");

        String idParam = req.getParameter("id");
        String planetIdParam = req.getParameter("planetId");

        if (idParam == null || planetIdParam == null ||
            idParam.isEmpty() || planetIdParam.isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"success\":false,\"message\":\"Missing parameters\"}");
            return;
        }

        long reportId;
        long planetId;
        try {
            reportId = Long.parseLong(idParam);
            planetId = Long.parseLong(planetIdParam);
        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"success\":false,\"message\":\"Invalid id or planetId\"}");
            return;
        }

        String sqlUpdatePlanet = "UPDATE planets SET isDeleted = 1 WHERE id = ?";
        String sqlUpdateReports = "UPDATE reports SET status = 'processed' WHERE planetId = ?";

        try (Connection conn = DBConnectionUtil.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(sqlUpdatePlanet);
                 PreparedStatement ps2 = conn.prepareStatement(sqlUpdateReports)) {

                // 1) 행성 soft delete
                ps1.setLong(1, planetId);
                int planetUpdated = ps1.executeUpdate();

                // 2) 해당 행성과 관련된 모든 신고 처리 완료
                ps2.setLong(1, planetId);
                ps2.executeUpdate();

                conn.commit();

                if (planetUpdated > 0) {
                    resp.getWriter().write("{\"success\":true}");
                } else {
                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
                    resp.getWriter().write("{\"success\":false,\"message\":\"Planet not found\"}");
                }

            } catch (SQLException ex) {
                conn.rollback();
                throw ex;
            } finally {
                conn.setAutoCommit(true);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"success\":false,\"message\":\"DB error\"}");
        }
    }
}
