// src/main/java/com/memoryspace/admin/AdminReportsServlet.java
package com.memoryspace.admin;

import com.memoryspace.db.DBConnectionUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "AdminReportsServlet", urlPatterns = {"/api/admin/reports"})
public class AdminReportsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json; charset=UTF-8");

        List<String> jsonRows = new ArrayList<>();

        String sql =
                "SELECT r.id, r.planetId, p.name AS planetName, " +
                "       u.nickname AS reporterNickname, r.reason, r.status " +
                "FROM reports r " +
                "LEFT JOIN planets p ON p.id = r.planetId " +
                "LEFT JOIN users u ON u.id = r.reporterUserId " +
                "ORDER BY r.id DESC";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                long id = rs.getLong("id");
                long planetId = rs.getLong("planetId");
                String planetName = rs.getString("planetName");
                String reporterNickname = rs.getString("reporterNickname");
                String reason = rs.getString("reason");
                String status = rs.getString("status");  // 'new' or 'processed'

                StringBuilder sb = new StringBuilder();
                sb.append("{");
                sb.append("\"id\":").append(id).append(",");
                sb.append("\"planetId\":").append(planetId).append(",");
                sb.append("\"planetName\":\"")
                  .append(planetName == null ? "" : escapeJson(planetName))
                  .append("\",");
                sb.append("\"reporterNickname\":\"")
                  .append(reporterNickname == null ? "" : escapeJson(reporterNickname))
                  .append("\",");
                sb.append("\"reason\":\"")
                  .append(reason == null ? "" : escapeJson(reason))
                  .append("\",");
                sb.append("\"status\":\"").append(escapeJson(status)).append("\"");
                sb.append("}");
                jsonRows.add(sb.toString());
            }

            String json = "{ \"reports\": [" + String.join(",", jsonRows) + "] }";
            resp.getWriter().write(json);

        } catch (SQLException e) {
            e.printStackTrace();
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"error\":\"DB error\"}");
        }
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
