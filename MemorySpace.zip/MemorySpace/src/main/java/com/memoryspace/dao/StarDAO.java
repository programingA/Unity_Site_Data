package com.memoryspace.dao;

import com.memoryspace.db.JdbcConnect;
import com.memoryspace.dto.StarDTO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StarDAO {

    public List<StarDTO> getStarsByUser(long userId) {
        List<StarDTO> list = new ArrayList<>();
        String sql = "SELECT * FROM stars WHERE userId = ?";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new StarDTO(
                    rs.getLong("id"),
                    rs.getLong("userId"),
                    rs.getString("name")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public boolean createStar(long userId, String name) {
        String sql = "INSERT INTO stars(userId, name) VALUES (?, ?)";
        try (Connection conn = JdbcConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, userId);
            ps.setString(2, name);
            return ps.executeUpdate() == 1;
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }
}
