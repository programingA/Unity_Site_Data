// src/components/main/Main.jsx (경로는 네 프로젝트 기준)

import React, { useState, useCallback, useEffect } from 'react';
import './Main.css';

import Header from "../header/Header";
import Login from "../signIn/Login";
import SignUp from "../signUp/SignUp";
import SpaceBackground from "../background/SpaceBackground";

// ✅ 여기만 프로젝트에 맞게 바꿔줘
//    예: http://localhost:8080/MemorySpace/  → CONTEXT_PATH = '/MemorySpace'
const CONTEXT_PATH = '/MemorySpace';

// 서버의 실제 경로(/MemorySpace/...)에서 React가 쓰는 논리 경로(/, /signup)만 뽑기
const stripContextPath = (pathname) => {
  if (!pathname.startsWith(CONTEXT_PATH)) return pathname || '/';

  let stripped = pathname.slice(CONTEXT_PATH.length); // "", "/index.html", "/signup" 등

  // ✅ 아무것도 없거나 "/index.html"이면 논리 경로 "/"로 취급
  if (stripped === '' || stripped === '/' || stripped === '/index.html') {
    return '/';
  }

  return stripped.startsWith('/') ? stripped : `/${stripped}`;
};


const Main = () => {
  // 로그인 모달 열림 여부
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  // 처음 로드할 때 현재 URL에서 논리 경로(/, /signup) 추출
  const initialPathname = window.location.pathname || '/';
  const initialLogical = stripContextPath(initialPathname);
  const [currentPage, setCurrentPage] = useState(
    initialLogical === '/signup' ? '/signup' : '/'
  );

  const handleOpenLogin = () => setIsLoginModalOpen(true);
  const handleCloseLogin = () => setIsLoginModalOpen(false);

  /**
   * navigate
   *  - path: "/signup" 또는 "/"
   *  - options.openLogin: true면 이동하면서 로그인 모달도 띄움
   */
  const CONTEXT_PATH = '/MemorySpace';  // 이건 그대로
  
  const navigate = useCallback((path, options = {}) => {
    const logicalPath = path.startsWith('/') ? path : `/${path}`;
  
    // ✅ "/"는 실제 URL로 "/MemorySpace/index.html" 사용
    let fullPath;
    if (logicalPath === '/') {
      fullPath = `${CONTEXT_PATH}/index.html`;
    } else {
      fullPath = `${CONTEXT_PATH}${logicalPath}`;
    }
  
    window.history.pushState({}, '', fullPath);
    setCurrentPage(logicalPath);
  
    if (options.openLogin) {
      setIsLoginModalOpen(true);
    } else {
      setIsLoginModalOpen(false);
    }
  }, []);


  // 🔁 브라우저 뒤로가기/앞으로가기(popstate) 처리
  useEffect(() => {
    const handlePopState = () => {
      const pathname = window.location.pathname || '/';
      const logical = stripContextPath(pathname);

      setCurrentPage(logical === '/signup' ? '/signup' : '/');
      // 뒤로가면서 모달 강제 열 필요는 없으니 기본은 닫기
      setIsLoginModalOpen(false);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const renderContent = () => {
    switch (currentPage) {
      case '/signup':
        return <SignUp navigate={navigate} />;
      case '/':
      default:
        return (
          <main className="main-wrapper">
            <SpaceBackground />
          </main>
        );
    }
  };

  return (
    <div className="app-root">
      <Header
        onLoginClick={handleOpenLogin}
        navigate={navigate}
      />

      {renderContent()}

      <Login
        isOpen={isLoginModalOpen}
        onClose={handleCloseLogin}
        navigate={navigate}
      />
    </div>
  );
};

export default Main;
