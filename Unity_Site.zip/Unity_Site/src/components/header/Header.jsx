// src/components/Header.jsx
import React from "react";
import "./Header.css";

function Header({
  onLoginClick,
  navigate,
  isLoggedIn,
  nickname,
  onMySpaceClick,
  onLogout,        // 🔹 로그아웃 콜백 추가
}) {
  const handleLogoClick = () => {
    if (navigate) navigate("/");
  };

  const handleSignupClick = () => {
    if (navigate) navigate("/signup");
  };

  const handleMySpaceClick = () => {
    if (onMySpaceClick) {
      onMySpaceClick();
    } else if (navigate) {
      navigate("/my-space");
    }
  };

  const handleSignInClick = () => {
    if (navigate) navigate("/");
    if (onLoginClick) onLoginClick();
  };

  const handleLogoutClick = () => {
    // 🔹 Main.jsx에서 넘겨준 onLogout 실행
    if (onLogout) onLogout();
  };

  const logoSrc = `${process.env.PUBLIC_URL}/logo.png`;

  return (
    <header className="header">
      <div className="header-inner">
        {/* LOGO */}
        <div className="logo" onClick={handleLogoClick}>
          <img src={logoSrc} alt="logo" className="logo-icon" />
          <span>Memory Space</span>
        </div>

        {/* RIGHT AREA */}
        <div className="auth-buttons">
          {isLoggedIn ? (
            <>
              <span className="welcome-text">
                Welcome : {nickname || "User"}
              </span>
              <button className="myspace-btn" onClick={handleMySpaceClick}>
                My Space
              </button>
              <button className="logout-btn" onClick={handleLogoutClick}>
                Logout
              </button>
            </>
          ) : (
            <>
              <button className="login-btn" onClick={handleSignInClick}>
                Sign In
              </button>

              <button className="signup-btn" onClick={handleSignupClick}>
                Sign Up
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export default Header;
