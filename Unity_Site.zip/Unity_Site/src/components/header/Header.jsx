// src/components/Header.jsx
import React from "react";
import "./Header.css";

function Header({ onLoginClick, navigate }) {
  const handleLogoClick = () => {
    if (navigate) navigate('/');   // 로고는 홈으로만 이동
  };

  const handleSignupClick = () => {
    if (navigate) navigate('/signup');
  };

  // Sign In: 홈으로 이동 + 로그인 모달 열기
  const handleSignInClick = () => {
    if (navigate) navigate('/');
    if (onLoginClick) onLoginClick();
  };

  const logoSrc = `${process.env.PUBLIC_URL}/logo.png`;

  return (
    <header className="header">
      <div className="header-inner">
        <div className="logo" onClick={handleLogoClick}>
          <img src={logoSrc} alt="logo" className="logo-icon" />
          <span>Memory Space</span>
        </div>

        <div className="auth-buttons">
          <button className="login-btn" onClick={handleSignInClick}>
            Sign In
          </button>
          <button className="signup-btn" onClick={handleSignupClick}>
            Sign Up
          </button>
        </div>
      </div>
    </header>
  );
}

export default Header;
