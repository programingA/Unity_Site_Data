import React, { useEffect, useRef, useState } from 'react'; 
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './MapPage.css';

// 🔹 마커 아이콘 이미지 깨짐 방지 코드
import iconMarker from 'leaflet/dist/images/marker-icon.png';
import iconRetina from 'leaflet/dist/images/marker-icon-2x.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

// ⭐️ Context Path 정의 (Java 서버의 Context Root와 일치해야 함)
const CONTEXT_PATH = "/MemorySpace"; 
const API_BASE = `${CONTEXT_PATH}/api`; // /MemorySpace/api

const MapPage = () => {
    const mapContainerRef = useRef(null);
    const mapInstanceRef = useRef(null);
    
    // ⭐️ 1. API에서 가져온 원본 위치 데이터
    const [rawLocations, setRawLocations] = useState([]); 
    const [currentZoom, setCurrentZoom] = useState(3);

    // 🔹 파란색 계열 색상 배열
    const blueColors = [
        '#3366FF', '#007FFF', '#00BFFF', '#1E90FF', '#6495ED',
        '#4169E1', '#0000FF', '#0000CD', '#00008B', '#00BFF7'
    ];

    // 🔹 무작위 색상 선택 함수
    const getRandomBlue = () => {
        return blueColors[Math.floor(Math.random() * blueColors.length)];
    };

    // ⭐️ 두 지점 간의 거리 계산 (km 단위)
    const getDistance = (lat1, lng1, lat2, lng2) => {
        const R = 6371; // 지구 반지름 (km)
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLng = (lng2 - lng1) * Math.PI / 180;
        const a = 
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng / 2) * Math.sin(dLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    };

    // ⭐️ 줌 레벨에 따른 클러스터링 거리 계산 (km)
    const getClusterDistance = (zoom) => {
        // 줌 레벨이 낮을수록(축소) 더 넓은 범위를 그룹화
        if (zoom <= 2) return 2000;    // 세계 전체 뷰 (2000km)
        if (zoom <= 3) return 1000;    // 대륙 뷰 (1000km)
        if (zoom <= 4) return 500;     // 대륙 뷰 (500km)
        if (zoom <= 5) return 300;     // 국가 뷰 (300km)
        if (zoom <= 6) return 150;     // 국가 뷰 (150km)
        if (zoom <= 7) return 80;      // 지역 뷰 (80km)
        if (zoom <= 8) return 40;      // 도시 뷰 (40km)
        if (zoom <= 9) return 20;      // 도시 뷰 (20km)
        if (zoom <= 10) return 10;     // 동네 뷰 (10km)
        if (zoom <= 11) return 5;      // 동네 뷰 (5km)
        return 1;                      // 상세 뷰 (1km)
    };

    // ⭐️ 2. 서버에서 지오코딩된 데이터를 가져오는 함수
    const fetchMapData = async () => {
        try {
            const response = await fetch(`${API_BASE}/map`); 
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            
            setRawLocations(data);
            console.log("Map data loaded:", data);

        } catch (error) {
            console.error("Failed to fetch map data:", error);
            setRawLocations([]);
        }
    };

    // ⭐️ 3. 거리 기반 클러스터링
    const clusterLocations = (locations, zoom) => {
        const maxDistance = getClusterDistance(zoom);
        const clusters = [];
        const used = new Set();

        locations.forEach((location, index) => {
            if (used.has(index)) return;

            const cluster = {
                lat: location.lat,
                lng: location.lng,
                name: location.name,
                items: [location],
                totalSize: location.value || 0,
                count: 1,
                indices: [index]
            };

            // 현재 위치와 가까운 다른 위치들을 찾아서 클러스터에 추가
            locations.forEach((otherLocation, otherIndex) => {
                if (used.has(otherIndex) || index === otherIndex) return;

                const distance = getDistance(
                    location.lat, 
                    location.lng, 
                    otherLocation.lat, 
                    otherLocation.lng
                );

                // 거리가 임계값보다 작으면 클러스터에 추가
                if (distance <= maxDistance) {
                    cluster.items.push(otherLocation);
                    cluster.totalSize += otherLocation.value || 0;
                    cluster.count += 1;
                    cluster.indices.push(otherIndex);
                    used.add(otherIndex);
                }
            });

            // 클러스터의 중심을 평균 좌표로 계산
            if (cluster.items.length > 1) {
                const avgLat = cluster.items.reduce((sum, item) => sum + item.lat, 0) / cluster.items.length;
                const avgLng = cluster.items.reduce((sum, item) => sum + item.lng, 0) / cluster.items.length;
                cluster.lat = avgLat;
                cluster.lng = avgLng;
            }

            clusters.push(cluster);
            used.add(index);
        });

        console.log(`Zoom ${zoom}: Clustered ${locations.length} locations into ${clusters.length} clusters`);
        return clusters;
    };

    // ⭐️ 4. 지도 초기화 및 데이터 로딩 (최초 1회 실행)
    useEffect(() => {
        if (mapInstanceRef.current) return;
        
        // 데이터 로딩 시작
        fetchMapData(); 

        // --- 기본 아이콘 설정 ---
        const DefaultIcon = L.icon({
            iconUrl: iconMarker,
            iconRetinaUrl: iconRetina,
            shadowUrl: iconShadow,
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });
        L.Marker.prototype.options.icon = DefaultIcon;

        // --- 지도 범위 제한 ---
        const corner1 = L.latLng(-85, -180);
        const corner2 = L.latLng(85, 180);
        const bounds = L.latLngBounds(corner1, corner2);

        // --- 지도 생성 ---
        const map = L.map(mapContainerRef.current, {
            center: [20, 0],
            zoom: 3, 
            minZoom: 2,
            maxBounds: bounds,
            maxBoundsViscosity: 1.0
        });

        mapInstanceRef.current = map;

        // --- 타일 레이어 ---
        L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap &copy; CARTO',
            subdomains: 'abcd',
            maxZoom: 19,
            noWrap: true,
            bounds: bounds
        }).addTo(map);

        L.control.scale({ imperial: true, metric: true }).addTo(map);

        // ⭐️ 줌 이벤트 리스너 추가
        map.on('zoomend', () => {
            setCurrentZoom(map.getZoom());
        });

        return () => {
            if (mapInstanceRef.current) {
                mapInstanceRef.current.remove();
                mapInstanceRef.current = null;
            }
        };
    }, []); // 의존성 배열 비어있음: 컴포넌트 마운트 시 1회 실행

    // ⭐️ 5. rawLocations나 currentZoom이 변경될 때마다 마커를 다시 그리기
    useEffect(() => {
        // 지도 인스턴스가 없거나 데이터가 없으면 실행 중지
        if (!mapInstanceRef.current || rawLocations.length === 0) return;

        const map = mapInstanceRef.current;
        
        // 현재 줌 레벨에 따라 클러스터링
        const clusteredLocations = clusterLocations(rawLocations, currentZoom);
        
        // 기존에 추가된 CircleMarker와 Marker 레이어 제거 (중복 방지)
        map.eachLayer(layer => {
            // TileLayer(지도의 배경)가 아닌 레이어만 제거
            if (layer instanceof L.CircleMarker || layer instanceof L.Marker) { 
                map.removeLayer(layer);
            }
        });

        // 🔹 각 클러스터에 CircleMarker와 숫자 아이콘 표시
        clusteredLocations.forEach((loc) => {
            // 🔹 값에 따른 반지름 (크기) 계산
            const baseRadius = 15; // 기본 원 크기
            const radiusMultiplier = 0.1;
            const maxPossibleValue = 10000000; // 10MB (10,000,000 bytes)를 최대값으로 가정하여 스케일링
            
            const scaledValue = Math.min(loc.totalSize, maxPossibleValue); // 최대값으로 크기 제한
            const calculatedRadius = baseRadius + (scaledValue / maxPossibleValue) * baseRadius * radiusMultiplier;

            // 🔹 값에 따른 투명도 계산
            const baseOpacity = 0.9;
            const opacityReductionFactor = 0.5;
            const calculatedOpacity = Math.max(0.3, baseOpacity - (scaledValue / maxPossibleValue) * opacityReductionFactor); 

            const randomBlue = getRandomBlue();

            // 🔹 CircleMarker (원) 추가
            L.circleMarker([loc.lat, loc.lng], {
                color: randomBlue,      
                weight: 2,             
                fillColor: randomBlue,  
                fillOpacity: calculatedOpacity, 
                radius: calculatedRadius 
            })
            .addTo(map)
            .bindPopup(`
                <b>${loc.name}</b><br>
                미디어 개수: ${loc.count}개<br>
                총 크기: ${(loc.totalSize / 1024 / 1024).toFixed(2)}MB
            `);

            // 🔹 DivIcon (개수 숫자) 추가
            const numberIcon = L.divIcon({
                className: 'number-icon', 
                html: `<div style="
                    color: white; 
                    font-weight: bold; 
                    font-size: 14px;
                    text-align: center;
                    line-height: 20px;
                    text-shadow: 1px 1px 2px rgba(0,0,0,0.5);
                ">${loc.count}</div>`, 
                iconSize: [20, 20],
                iconAnchor: [10, 10]
            });

            L.marker([loc.lat, loc.lng], { icon: numberIcon }).addTo(map);
        });

    }, [rawLocations, currentZoom]); // rawLocations 또는 currentZoom이 변경될 때마다 실행

    return (
        <div className="map-page-container">
            <div id="map" ref={mapContainerRef}></div>
        </div>
    );
};

export default MapPage;