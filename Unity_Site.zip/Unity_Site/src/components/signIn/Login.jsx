// src/components/Login.jsx
import React, { useState } from 'react';
import './Login.css';

/**
 * 로그인 모달 컴포넌트
 * @param {object} props
 * @param {boolean} props.isOpen
 * @param {function} props.onClose
 * @param {function} props.navigate
 */

// src/components/signIn/Login.jsx

// ✅ 위쪽 import 밑에 추가
const CONTEXT_PATH = '/MemorySpace';     // 위 Main.jsx와 반드시 동일해야 함
const API_BASE = `${CONTEXT_PATH}/api`;

const Login = ({ isOpen, onClose, navigate }) => {
  const [id, setId] = useState('');
  const [password, setPassword] = useState('');

  if (!isOpen) return null;

  // 🔥 실제 서블릿 호출 부분
  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const response = await fetch(`${API_BASE}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        },
        body: new URLSearchParams({
          id,
          password,
        }).toString(),
      });
  
      if (!response.ok) throw new Error('Server error');
  
      const data = await response.json();
  
      if (data.success) {
        console.log('로그인 성공:', data);
        onClose();
        if (navigate) {
          // 메인으로 이동 (컨텍스트 경로는 Main.jsx에서 붙여줌)
          navigate('/');
        }
      } else {
        alert(data.message || '아이디 또는 비밀번호가 올바르지 않습니다.');
      }
    } catch (err) {
      console.error('로그인 요청 실패:', err);
      alert('서버 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    }
  };


  const handleSignupClick = (e) => {
    e.preventDefault();
    onClose(); // 모달 닫기
    if (navigate) {
      navigate('/signup');
    }
  };

  return (
    // 모달 배경 (클릭 시 닫기 기능)
    <div className="modal-overlay" onClick={onClose}>
      {/* 모달 내용 클릭 시는 닫히지 않게 막기 */}
      <div className="login-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-button" onClick={onClose}>×</button>
        <h2>Sign In</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="login-id">USERNAME</label>
            <input
              type="text"
              id="login-id"
              value={id}
              onChange={(e) => setId(e.target.value)}
              required
              placeholder="ID"
            />
          </div>
          <div className="form-group">
            <label htmlFor="login-password">PASSWORD</label>
            <input
              type="password"
              id="login-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="Password"
            />
          </div>
          <button type="submit" className="login-button">Login</button>
        </form>
        <p className="signup-link">
          New to Memory Space?
          <a href="#" onClick={handleSignupClick}>Create an account</a>
        </p>
      </div>
    </div>
  );
};

export default Login;
