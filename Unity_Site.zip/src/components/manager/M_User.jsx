// manager/M_User.jsx
import React, { useEffect, useState } from "react";
import "./M_User.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

/**
 * 관리자 - 회원 목록 테이블
 * DB: users + (행성/별 등) 조인해서 postCount까지 내려주면 좋음
 */
function M_User() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // 🔹 회원 목록 조회
  const fetchUsers = async () => {
    try {
      setLoading(true);
      const res = await fetch(`${API_BASE}/admin/users`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });

      if (!res.ok) {
        throw new Error("사용자 목록을 불러오지 못했습니다.");
      }

      const data = await res.json();
      // 백엔드에서 { users: [...] } 형태로 내려준다고 가정
      setUsers(Array.isArray(data.users) ? data.users : []);
      setError(null);
    } catch (err) {
      console.error("관리자 - 사용자 목록 조회 실패:", err);
      setError(err.message || "사용자 목록 조회 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="m-user-container">
      <h2>회원 목록</h2>

      {/* 새로고침 버튼 / 에러 메시지 */}
      <div style={{ marginBottom: "10px", display: "flex", gap: "10px" }}>
        <button
          onClick={fetchUsers}
          style={{
            padding: "6px 12px",
            backgroundColor: "#3E4C5F",
            color: "white",
            borderRadius: "6px",
            border: "none",
            cursor: "pointer",
          }}
        >
          새로고침
        </button>
        {error && (
          <span style={{ color: "#ff8888", fontSize: "0.9rem" }}>
            {error}
          </span>
        )}
      </div>

      {loading ? (
        <p>회원 목록을 불러오는 중입니다...</p>
      ) : users.length === 0 ? (
        <p>등록된 회원이 없습니다.</p>
      ) : (
        <table className="m-user-table">
          <thead>
            <tr>
              <th>이름(닉네임)</th>
              <th>게시물 수</th>
              <th>이메일</th>
              <th>지역</th>
              <th>권한</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id ?? user.username}>
                <td>{user.nickname || user.username}</td>
                <td>{user.postCount ?? 0}</td>
                <td>{user.email}</td>
                <td>{user.liveIn || "-"}</td>
                <td>{user.role}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default M_User;
