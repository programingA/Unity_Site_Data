// manager/M_Decl.jsx
import React, { useEffect, useState } from "react";
import "./M_Decl.css";

const CONTEXT_PATH = "/MemorySpace";
const API_BASE = `${CONTEXT_PATH}/api`;

/**
 * 관리자 - 신고된 게시물 관리
 * DB: reports + planets + users 조인해서 내려오는 데이터 표시
 */
function M_Decl() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // 🔹 신고 목록 조회
  const fetchReports = async () => {
    try {
      setLoading(true);
      const res = await fetch(`${API_BASE}/admin/reports`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
      });

      if (!res.ok) {
        throw new Error("신고 목록을 불러오지 못했습니다.");
      }

      const data = await res.json();
      setReports(Array.isArray(data.reports) ? data.reports : []);
      setError(null);
    } catch (err) {
      console.error("관리자 - 신고 목록 조회 실패:", err);
      setError(err.message || "신고 목록 조회 중 오류가 발생했습니다.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReports();
  }, []);

  // 🔹 신고 처리 완료
  const handleResolve = async (reportId) => {
    if (!window.confirm("이 신고를 처리 완료 상태로 변경하시겠습니까?")) return;

    try {
      const res = await fetch(
        `${API_BASE}/admin/reports/${reportId}/resolve`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!res.ok) {
        throw new Error("신고 처리에 실패했습니다.");
      }

      // 상태만 'processed' 로 변경
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId ? { ...r, status: "processed" } : r
        )
      );
    } catch (err) {
      console.error("신고 처리 실패:", err);
      alert(err.message || "신고 처리 중 오류가 발생했습니다.");
    }
  };

  // 🔹 신고된 게시물(행성) 삭제
  const handleDeletePlanet = async (reportId, planetId) => {
    if (
      !window.confirm(
        `행성(ID: ${planetId})과 관련된 게시물을 삭제하시겠습니까?`
      )
    )
      return;

    try {
      const res = await fetch(
        `${API_BASE}/admin/reports/${reportId}/delete-planet`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      if (!res.ok) {
        throw new Error("게시물 삭제에 실패했습니다.");
      }

      // 삭제된 신고는 목록에서 제거
      setReports((prev) => prev.filter((r) => r.id !== reportId));
    } catch (err) {
      console.error("게시물 삭제 실패:", err);
      alert(err.message || "게시물 삭제 중 오류가 발생했습니다.");
    }
  };

  return (
    <div className="m-decl-container">
      <h2>신고된 게시물</h2>

      <div
        style={{ marginBottom: "10px", display: "flex", gap: "10px" }}
      >
        <button
          onClick={fetchReports}
          style={{
            padding: "6px 12px",
            backgroundColor: "#3E4C5F",
            color: "white",
            borderRadius: "6px",
            border: "none",
            cursor: "pointer",
          }}
        >
          새로고침
        </button>
        {error && (
          <span style={{ color: "#ff8888", fontSize: "0.9rem" }}>
            {error}
          </span>
        )}
      </div>

      <div className="m-decl-scroll">
        {loading ? (
          <div className="m-decl-empty">신고 목록을 불러오는 중입니다...</div>
        ) : reports.length === 0 ? (
          <div className="m-decl-empty">신고된 게시물이 없습니다.</div>
        ) : (
          reports.map((r) => (
            <div className="m-decl-box" key={r.id}>
              <h3>{r.planetName || "제목 없는 게시물"}</h3>
              <p>게시물(행성) 번호: {r.planetId}</p>
              <p>신고자: {r.reporterNickname || "익명"}</p>
              <p>사유: {r.reason}</p>
              <p>상태: {r.status === "processed" ? "처리 완료" : "신규"}</p>

              <button onClick={() => handleResolve(r.id)}>
                신고 처리 완료
              </button>
              <button onClick={() => handleDeletePlanet(r.id, r.planetId)}>
                게시물 삭제
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default M_Decl;
